  function resizeDialogToContent()
  {
    // resize window so there are no scrollbars visible
    window.sizeToContent();
  }
  
