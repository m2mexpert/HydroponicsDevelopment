<?php
echo "Raspberry Pi Time: " . date("M d Y h:i:s A");
?>
