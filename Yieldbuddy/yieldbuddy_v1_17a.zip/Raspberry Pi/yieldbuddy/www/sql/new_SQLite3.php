<?php
$db = new SQLite3($_SERVER['DOCUMENT_ROOT'] . '/yieldbuddy/www/sql/yieldbuddy.sqlite3');
#$db = new SQLite3('/mnt/usb/yieldbuddy.sqlite3');
?>
